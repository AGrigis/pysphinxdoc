"""
Basic example with cross-references
===================================

A simple example of how to document API objects.
"""
# sphinx_gallery_thumbnail_path = "_static/pysphinxdoc.png"

from pysphinxdoc.utils import dummy


dummy()
